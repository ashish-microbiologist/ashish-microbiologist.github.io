<?php
session_start();

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

include '../config.php';

$message = '';
$message_type = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $app_name = $conn->real_escape_string($_POST['app_name']);
    $app_version = $conn->real_escape_string($_POST['app_version']);
    $app_size = $conn->real_escape_string($_POST['app_size']);
    $download_link = $conn->real_escape_string($_POST['download_link']);
    $features = $conn->real_escape_string($_POST['features']);
    $category = $conn->real_escape_string($_POST['category']);
    
    // Handle file upload
    $app_logo = '';
    if(isset($_FILES['app_logo']) && $_FILES['app_logo']['error'] == 0) {
        $file_name = time() . '_' . basename($_FILES['app_logo']['name']);
        $target_path = "../uploads/images/" . $file_name;
        
        // Check file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $file_type = $_FILES['app_logo']['type'];
        
        if(in_array($file_type, $allowed_types)) {
            if(move_uploaded_file($_FILES['app_logo']['tmp_name'], $target_path)) {
                $app_logo = $file_name;
            }
        }
    }
    
    // Insert into database
    $sql = "INSERT INTO apps (app_name, app_version, app_size, app_logo, download_link, features, category) 
            VALUES ('$app_name', '$app_version', '$app_size', '$app_logo', '$download_link', '$features', '$category')";
    
    if($conn->query($sql)) {
        $message = 'App added successfully!';
        $message_type = 'success';
    } else {
        $message = 'Error: ' . $conn->error;
        $message_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New App - OP ASHISH YT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #ff4757 0%, #ff2e43 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: white;
            text-decoration: none;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.2);
            border-radius: 5px;
        }
        
        .form-container {
            padding: 30px;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        .required::after {
            content: " *";
            color: #ff4757;
        }
        
        input[type="text"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        input:focus,
        textarea:focus,
        select:focus {
            border-color: #ff4757;
            outline: none;
        }
        
        textarea {
            resize: vertical;
            min-height: 120px;
        }
        
        .file-input {
            border: 2px dashed #ddd;
            padding: 20px;
            text-align: center;
            border-radius: 8px;
            background: #f8f9fa;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .file-input:hover {
            border-color: #ff4757;
            background: #fff5f5;
        }
        
        .file-input input {
            display: none;
        }
        
        .file-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }
        
        .file-label i {
            font-size: 40px;
            color: #667eea;
        }
        
        .submit-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 10px;
            }
            
            .header, .form-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-plus-circle"></i> Add New MOD APK</h1>
            <p>Fill all details to add new app to website</p>
            <a href="dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="form-container">
            <?php if($message): ?>
                <div class="message <?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="required"><i class="fas fa-mobile-alt"></i> App Name</label>
                    <input type="text" name="app_name" required 
                           placeholder="e.g., WhatsApp MOD, YouTube Premium">
                </div>
                
                <div class="form-group">
                    <label class="required"><i class="fas fa-code-branch"></i> App Version</label>
                    <input type="text" name="app_version" required 
                           placeholder="e.g., 2.23.10">
                </div>
                
                <div class="form-group">
                    <label class="required"><i class="fas fa-weight"></i> App Size</label>
                    <input type="text" name="app_size" required 
                           placeholder="e.g., 45 MB, 85 MB">
                </div>
                
                <div class="form-group">
                    <label class="required"><i class="fas fa-folder"></i> Category</label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <option value="Games">Games</option>
                        <option value="Apps">Apps</option>
                        <option value="Tools">Tools</option>
                        <option value="Social">Social Media</option>
                        <option value="Entertainment">Entertainment</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-image"></i> App Logo</label>
                    <div class="file-input">
                        <label class="file-label">
                            <input type="file" name="app_logo" accept="image/*">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <span>Click to upload app logo</span>
                            <small>Recommended: PNG/JPG, Max 2MB</small>
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="required"><i class="fas fa-link"></i> Download Link</label>
                    <input type="url" name="download_link" required 
                           placeholder="https://example.com/download.apk">
                </div>
                
                <div class="form-group">
                    <label class="required"><i class="fas fa-star"></i> MOD Features</label>
                    <textarea name="features" required 
                              placeholder="Enter MOD features (one per line)
• Unlimited Money
• No Ads
• Premium Unlocked
• All Features Available"></textarea>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-save"></i> Add App to Website
                </button>
            </form>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>