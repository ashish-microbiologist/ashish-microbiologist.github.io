<?php
session_start();

// Check login
if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

include '../config.php';

// Logout
if(isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Delete app
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM apps WHERE id = '$id'";
    $conn->query($sql);
    header('Location: dashboard.php');
    exit();
}

// Get all apps
$sql = "SELECT * FROM apps ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - OP ASHISH YT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #ff4757;
            --dark: #2c3e50;
            --light: #f8f9fa;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
            background: var(--light);
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: var(--dark);
            color: white;
            padding-top: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .brand {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .brand h2 {
            color: var(--primary);
            font-size: 24px;
        }
        
        .menu {
            padding: 20px 0;
        }
        
        .menu-item {
            padding: 12px 25px;
            display: block;
            color: white;
            text-decoration: none;
            transition: 0.3s;
            border-left: 4px solid transparent;
        }
        
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: var(--primary);
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .topbar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .stat-card h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .stat-card .number {
            font-size: 36px;
            font-weight: bold;
            color: var(--primary);
        }
        
        /* Table */
        .table-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: var(--dark);
        }
        
        .app-logo {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 14px;
        }
        
        .btn-edit {
            background: #3498db;
            color: white;
        }
        
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                height: auto;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="brand">
            <h2><i class="fas fa-user-shield"></i> ADMIN PANEL</h2>
            <p style="color: #aaa; font-size: 14px;">OP ASHISH YT</p>
        </div>
        
        <div class="menu">
            <a href="dashboard.php" class="menu-item active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="add-app.php" class="menu-item">
                <i class="fas fa-plus-circle"></i> Add App
            </a>
            <a href="../index.php" target="_blank" class="menu-item">
                <i class="fas fa-eye"></i> View Website
            </a>
            <a href="?logout=true" class="menu-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="topbar">
            <h1>Dashboard</h1>
            <div>
                <a href="add-app.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New App
                </a>
            </div>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Apps</h3>
                <div class="number"><?php echo $result->num_rows; ?></div>
            </div>
        </div>
        
        <!-- Apps Table -->
        <div class="table-container">
            <h2>All Apps</h2>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Logo</th>
                        <th>App Name</th>
                        <th>Version</th>
                        <th>Size</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($app = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $app['id']; ?></td>
                            <td>
                                <?php if(!empty($app['app_logo'])): ?>
                                    <img src="../uploads/images/<?php echo $app['app_logo']; ?>" 
                                         class="app-logo" 
                                         alt="<?php echo $app['app_name']; ?>">
                                <?php else: ?>
                                    <div style="width:50px;height:50px;background:#3498db;border-radius:8px;display:flex;align-items:center;justify-content:center;color:white;">
                                        <i class="fas fa-mobile-alt"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $app['app_name']; ?></td>
                            <td><?php echo $app['app_version']; ?></td>
                            <td><?php echo $app['app_size']; ?></td>
                            <td>
                                <div class="actions">
                                    <a href="edit-app.php?id=<?php echo $app['id']; ?>" class="btn btn-sm btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="?delete=<?php echo $app['id']; ?>" 
                                       class="btn btn-sm btn-delete"
                                       onclick="return confirm('Delete this app?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 30px;">
                                <h3>No apps found</h3>
                                <p>Add your first app using "Add New App" button</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>