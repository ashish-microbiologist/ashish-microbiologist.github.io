<?php
// setup.php - Run this file once to create database
echo "<h3>Database Setup for OP ASHISH YT</h3>";

$host = 'localhost';
$username = 'root';
$password = '';

// Create connection
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS op_ashish_yt";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

// Select database
$conn->select_db("op_ashish_yt");

// Create apps table
$sql = "CREATE TABLE IF NOT EXISTS apps (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    app_name VARCHAR(200) NOT NULL,
    app_version VARCHAR(50),
    app_size VARCHAR(50),
    app_logo VARCHAR(255),
    download_link TEXT NOT NULL,
    features TEXT,
    category VARCHAR(100),
    download_count INT(11) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'apps' created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Create sample data
$sql = "INSERT INTO apps (app_name, app_version, app_size, category, download_link, features) 
        VALUES 
        ('WhatsApp MOD', '2.23.10', '45 MB', 'Social', 'https://example.com/whatsapp.apk', '• Blue ticks hide\n• Anti-ban\n• Custom themes'),
        ('YouTube Premium', '18.45.43', '85 MB', 'Apps', 'https://example.com/youtube.apk', '• No ads\n• Background play\n• Download videos')";

if ($conn->query($sql) === TRUE) {
    echo "Sample data inserted successfully<br>";
} else {
    echo "Error inserting data: " . $conn->error . "<br>";
}

echo "<h3>Setup Completed Successfully!</h3>";
echo "<p>Now you can:</p>";
echo "<ol>
<li>Go to <a href='index.php'>Website</a></li>
<li>Login to <a href='admin/login.php'>Admin Panel</a></li>
<li>Username: opashishyt</li>
<li>Password: Ashish@2006</li>
</ol>";

$conn->close();
?>